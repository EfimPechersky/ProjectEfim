package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class LevelActivity extends AppCompatActivity {
    Button back,tile1,tile2,tile3,tile4,tile5,tile6,startbutton;
    int[]tiles={1,2,2,4,6,4,1,3,6,4,5,3};
    int[]delays={3000,1000,4000,3000,2000,1200,3456,6000,2000,2500,1000,1000};
    Level level=new Level(tiles,delays,R.raw.jojo);
    Thread thread=new Thread();
    Timer timer = new Timer();
    SoundPool mSoundPool;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);
        mSoundPool=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        tile1=findViewById(R.id.tile1);
        tile2=findViewById(R.id.tile2);
        tile3=findViewById(R.id.tile3);
        tile4=findViewById(R.id.tile4);
        tile5=findViewById(R.id.tile5);
        tile6=findViewById(R.id.tile6);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        startbutton=findViewById(R.id.test);
        back=findViewById(R.id.back);
        tile1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.bassgitarafankzvonkaya,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.gitarabassodinochnyiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.gitaraodinochnyiychetkiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.gitaraodinochnyiyzvonkiysredniy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.malyiybarabanodinochnyiyrimchetkiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.load(LevelActivity.this,R.raw.malyiybarabanodinochnyiyvprostranstveklassicheskiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        Bundle bundle=new Bundle();
        bundle=getIntent().getExtras();
        Long levelID=bundle.getLong("levelID");
        final Intent intent=new Intent(LevelActivity.this,MainActivity.class);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startbutton.setText("");
                class MyTimerTask1 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("1");
                    }
                }
                class MyTimerTask2 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("2");
                    }
                }
                class MyTimerTask3 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("3");
                    }
                }
                class MyTimerTask4 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("4");
                    }
                }
                class MyTimerTask5 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("5");
                    }
                }
                class MyTimerTask6 extends TimerTask {
                    @Override
                    public void run() {
                        startbutton.setText("6");
                    }
                }
                Button button = null;
                for (int i = 0; i < level.tiles.length; i++) {
                    switch (level.tiles[i]) {
                        case(1):button=tile1;
                        case(2):button=tile2;
                        case(3):button=tile3;
                        case(4):button=tile4;
                        case(5):button=tile5;
                        case(6):button=tile6;
                    }
                    switch (level.tiles[i]) {
                        case (1):
                            MyTimerTask1 myTimerTask1=new MyTimerTask1();
                            timer.schedule(myTimerTask1,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case (2):
                            MyTimerTask2 myTimerTask2=new MyTimerTask2();
                            timer.schedule(myTimerTask2,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case (3):
                            MyTimerTask3 myTimerTask3=new MyTimerTask3();
                            timer.schedule(myTimerTask3,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case (4):
                            MyTimerTask4 myTimerTask4=new MyTimerTask4();
                            timer.schedule(myTimerTask4,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case (5):
                            MyTimerTask5 myTimerTask5=new MyTimerTask5();
                            timer.schedule(myTimerTask5,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        case (6):
                            MyTimerTask6 myTimerTask6=new MyTimerTask6();
                            timer.schedule(myTimerTask6,level.delays[i]);
                            try {
                                TimeUnit.MILLISECONDS.sleep(level.delays[i]);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                    }

                }
            }
        });
    }

}